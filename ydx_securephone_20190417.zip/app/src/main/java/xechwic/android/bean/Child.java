package xechwic.android.bean;

import java.io.Serializable;

import xechwic.android.FriendNodeInfo;


@SuppressWarnings("serial")
public class Child extends FriendNodeInfo implements Serializable{

	
}
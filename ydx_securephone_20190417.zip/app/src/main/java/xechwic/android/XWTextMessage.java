package xechwic.android;

/**
 * Created by luman on 2017/1/5 21:40
 */

class XWTextMessage{
    public int type;
    public int senderID;
    public byte []content;
    public byte [] btime;
    String sSenderName;
}

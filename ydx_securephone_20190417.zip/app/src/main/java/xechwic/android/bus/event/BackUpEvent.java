package xechwic.android.bus.event;

/**
 * Created by luman on 2017/4/28 12:34
 */

public class BackUpEvent {
  public int type;///1,备份
  public BackUpEvent(int type){
    this.type=type;
  }
}

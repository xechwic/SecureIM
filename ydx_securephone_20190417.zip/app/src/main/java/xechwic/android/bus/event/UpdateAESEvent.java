package xechwic.android.bus.event;

/**
 * Created by luman on 2016/12/30 10:00
 */

public class UpdateAESEvent {
}

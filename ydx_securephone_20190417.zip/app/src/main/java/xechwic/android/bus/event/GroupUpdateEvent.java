package xechwic.android.bus.event;

/**
 * Created by luman on 2016/9/10 13:33
 * 组管理事件
 */
public class GroupUpdateEvent {
}

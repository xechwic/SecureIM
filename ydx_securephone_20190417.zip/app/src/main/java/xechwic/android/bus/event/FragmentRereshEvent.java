package xechwic.android.bus.event;

/**
 * Created by luman on 2016/10/20 22:42
 */

public class FragmentRereshEvent {
    public int type=-1;
    public FragmentRereshEvent(int type){
        this.type=type;
    }
}

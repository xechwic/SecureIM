package com.example.mcryptolmsdimpl_demo;

//
// Source code recreated from TAG .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

import android.content.Context;
import android.content.res.AssetManager;


public  class MCryptoSDKInit {
    public MCryptoSDKInit() {
    }

    public  void init(Context var1, AssetManager var2, String var3){

    }

//    static {
//        System.loadLibrary("mcrypto");
//    }
}
